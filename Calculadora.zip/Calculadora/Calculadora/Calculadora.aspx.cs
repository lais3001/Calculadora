﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Calculadora
{
    public partial class Calculadora : System.Web.UI.Page
    {
        double valor1, valor2;
        int fatorial = 1;
        int exp, base1; 

        protected void Page_Load(object sender, EventArgs e)
        {
            Label1Resultado.Text += "";
        }

        protected void ButtonAdicao_Click(object sender, EventArgs e)
        {
            Label1Resultado.Text += "";

            valor1 = double.Parse(TextBoxValor1.Text);
            valor2 = double.Parse(TextBoxValor2.Text);

            Label1Resultado.Text += valor1 + valor2;
        }

        protected void ButtonSubtracao_Click(object sender, EventArgs e)
        {
            Label1Resultado.Text += "";

            valor1 = double.Parse(TextBoxValor1.Text);
            valor2 = double.Parse(TextBoxValor2.Text);

            Label1Resultado.Text += valor1 - valor2;
        }



        protected void ButtonMultiplicacao_Click(object sender, EventArgs e)
        {
            valor1 = double.Parse(TextBoxValor1.Text);
            valor2 = double.Parse(TextBoxValor2.Text);

            Label1Resultado.Text += valor1 * valor2;
        }

        protected void ButtonFatorial_Click(object sender, EventArgs e)
        {
            int numero = 1;
            fatorial = int.Parse(TextBoxFatorial.Text);                        

            for (int i = fatorial; i > 0; i--)
            {
                numero = numero * i;
            }

            Label1Resultado.Text += numero;
        }

        protected void ButtonExpoente_Click(object sender, EventArgs e)
        {
            exp = int.Parse(TextBoxExpoente.Text);
            base1= int.Parse(TextBoxBase.Text);

            Label1Resultado.Text += Convert.ToInt32(Math.Pow(exp, base1));


        }

        protected void ButtonDivisao_Click(object sender, EventArgs e)
        {
            valor1 = double.Parse(TextBoxValor1.Text);
            valor2 = double.Parse(TextBoxValor2.Text);

            Label1Resultado.Text += valor1 / valor2;
        }
    }
}